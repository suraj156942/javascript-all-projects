   <?php
include 'server.php';
if(isset($_POST['submit'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $contact=$_POST['contact'];
$query="INSERT INTO  student2(first_name,last_name,contact_number)VALUES('$fname','$lname','$contact')";
     if(mysqli_query($con,$query))
     {
        header('location:display.php');
        exit;
       }
     else
     {
       echo"Not inserted";
       
     }
// header('location:index.php');
}

?>




<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title></title>
<link rel="stylesheet" href="">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<div class="container">
<h1 class="text-center text-dark text-capitalize">Data insert </h1>
 <form  action="" method="POST">
 	<div class="col-lg-8 m-auto">
     <div class="form-group">
     	<label>First name</label>
     	<input type="text" name="fname" class="form-control" autocomplete="off" required>
     </div>
     <div class="form-group">
     	<label>Last name</label>
     	<input type="text" name="lname" class="form-control"autocomplete="off" required>
     
    <div class="form-group">
      <label>contact number</label>
      <input type="text" name="contact" class="form-control"autocomplete="off" required>
     </div>
     </div>
<input type="submit" id="submit" name="submit" class="btn btn-primary btn-block "onclick="alert('Do you want to  insert the data! ')";>
    </div>
</div>
</form>

</script>
</body>
</html>