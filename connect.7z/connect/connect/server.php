<?php

$username='root';
$password='';
$server='localhost';
$db='test';


$con=mysqli_connect($server,$username,$password,$db);
// if($con)
// {
// 	die("connection failed!".$conn->connect_error);
// }
// else
// {
// 	//echo 'failed';
// } 


?>