<?php
	include 'server.php';
	$sql = 'SELECT * FROM student2';
    $res = mysqli_query($con, $sql);
?>
<html>
	<head>
		<title>Display</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
		
	</head>
	<body>
		<div class="container">
		<table class="table">
			<tr>
				<th>Id</th>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Contact Number</th>
			</tr>
			<?php
			 if (mysqli_num_rows($res) > 0) {
            while($row = mysqli_fetch_assoc($res)) {
		?>
			<tr>
				<td>
					<?php  echo $row["id"]; ?>
				</td>
				<td>
					<?php  echo $row["first_name"] ;?>
				</td>
				<td>
					<?php  echo $row["last_name"]; ?>
				</td>
				<td>
					<?php  echo $row["contact_number"]; ?>
				</td>
				<td>
					<a href="edit.php?id=<?php echo $row["id"]?>" class="btn btn-success">Edit</a> 
				</td>
				<td>
					<a href="delete.php?id=<?php echo $row["id"]?>" class="btn btn-success">Delete</a> 
				</td>
			</tr>
		<?php 
			}
			 }
		?>
		</table>
	</div>
	</body>
</html>