<?php

session_start();
include 'server.php';
	$sql = 'SELECT * FROM info2';
    $res = mysqli_query($con, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
</head>
<body>
<h1>welcome <?php echo $_SESSION['user'] ?></h1>
<a href="logout.php" class="btn btn-primary">logout</a>
<br><br>
<body>
		<div class="container">
		<table class="table">
			<tr>
				<th>Id</th>
				<th> Name</th>
				<th>Password</th>
				
			</tr>
			<?php
			 if (mysqli_num_rows($res) > 0) {
            while($row = mysqli_fetch_assoc($res)) {
		?>
			<tr>
				<td>
					<?php  echo $row["id"]; ?>
				</td>
				<td>
					<?php  echo $row["name"] ;?>
				</td>
				<td>
					<?php  echo $row["password"]; ?>
				</td>
				
			<td>
					<a href="edit.php?id=<?php echo $row["id"]?>" class="btn btn-success">Edit</a> 
				</td>
				<td>
					<a href="delete.php?id=<?php echo $row["id"]?>" class="btn btn-success">Delete</a> 
				</td>	
			</tr>
		<?php 
			}
			 }
		?>
		</table>

</body>
</html>