<?php
include 'server.php';
$id=$_GET['id'];
$delete="DELETE FROM info2 WHERE id='$id'";
$data=mysqli_query($con,$delete);
if($data)
{
  echo " <font color='green'>Record delete";
}else
{
  echo "<font color='red'> Not";
}

?>