   <?php
include 'server.php';
session_start();
if(isset($_POST['submit'])){
    $username=$_POST['fname'];
    $password=$_POST['lname'];
    
$sql="select * from info2 where name='$username' and password='$password'";
$qry=mysqli_query($con,$sql);
$rw=mysqli_num_rows($qry);
    if($rw>0){
        $_SESSION['user']= $username;
        header('location:home.php');
    }
    else
    {
header('location:login.php');
    }
    
}

?>




<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title></title>
<link rel="stylesheet" href="">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
 <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
 <style>
    .container.one {
    border: 8px solid black;
    padding: 40px 0;
    background-image:linear-gradient(rgba(0,0,0,0.7),rgba(0,0,0,0.3)), url("https://images.pexels.com/photos/58639/pexels-photo-58639.jpeg?cs=srgb&dl=coffee-smartphone-twitter-application-58639.jpg&fm=jpg");
background-repeat: ;
background-repeat: no-repeat;
background-size: 100% 100%;
}
 </style>
</head>
<div class="container one">
<h1 class="text-center  text-capitalize text-primary ">login form </h1>
 <form  action="" method="POST">
 	<div class="col-lg-8 m-auto">
     <div class="form-group">
     	<label class="text-primary">Username</label>
     	<input type="text" name="fname" class="form-control" autocomplete="off" required>
     </div>
     <div class="form-group">
     	<label class="text-primary">Password</label>
     	<input type="text" name="lname" class="form-control"autocomplete="off" required>
     
  
     </div>
<input type="submit" id="submit" name="submit" class="btn btn-primary btn-block ">
 </div> 
</div>
</form>

</script>
</body>
</html>